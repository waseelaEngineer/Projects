<div class="text-center mb-5 mb-md-7 mb-lg-9 min-vh-50">
    <img class="mt-6" width="30%" src="<?php echo base_url('assets/front/img/not-found.png') ?>"><br><br>
    <h4 class="pt-300"><span><?php echo trans('no-data-found') ?></span></h4>
</div>