<?php include'include/header.php';?>
  <?php echo $main_content;?>
<?php include'include/footer.php';?>