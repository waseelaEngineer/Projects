<div class="content-wrapper">
  <section class="content">
    <div class="container mt-200 mb-20">
        <div class="text-center m-auto col-md-6">
            <div class="pay_status p-20">
              <h3><i class="icon-question text-success fa-2x"></i></h3>
              <p><strong class="mb-50"> Are you sure want to upgrade your plan?</strong></p><br>
              <a class="btn btn-success btn-lg" href="<?php echo base_url('admin/subscription/upgrade/'.$slug.'/'.$billing_type.'/1') ?>"><i class="ficon flaticon-check"></i> Yes Continue </a>
            </div>
        </div>
    </div>
  </section>
</div>